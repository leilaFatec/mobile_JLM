package renato.silva170.applistacontatos.servicos

import renato.silva170.applistacontatos.models.Contato
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.POST


interface ServicosContatos {
    @GET("contatos")
    fun getContatos(): Call<List<Contato>>

    @POST("Contatos")
    fun insereContatos(novoContato: Contato): Call<Contato>
}