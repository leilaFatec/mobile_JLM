package renato.silva170.applistacontatos.models
import java.io.Serializable

class Contato (
        val _id:String,
        val nome: String,
        val email: String,
        val telefone: String,
        val endereco: String,
        val foto: String
        ):Serializable

{
    override fun toString(): String {
        return super.toString()
    }
}

