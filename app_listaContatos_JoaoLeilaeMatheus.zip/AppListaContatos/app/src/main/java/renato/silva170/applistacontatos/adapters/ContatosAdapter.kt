package renato.silva170.applistacontatos.adapters

import android.view.LayoutInflater
import android.view.MenuInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import renato.silva170.applistacontatos.R
import renato.silva170.applistacontatos.models.Contato

class ContatosAdapter(private val listaContatos:ArrayList<Contato>) //alterei String para contato 14/07/2024
    :RecyclerView.Adapter<ContatosAdapter.ContatoViewHolder>() {

        var posicaoClicada:Int=-1

        class ContatoViewHolder(ItemView:View):RecyclerView.ViewHolder(ItemView) {
            val txtNome:TextView = ItemView.findViewById(R.id.txtNomedoContato)
            val txtTelefone: TextView = ItemView.findViewById(R.id.txtTelefoneContato) //criei essa nova 14/09/2024

            //pega um xml e desenha a classe daquele xml (inflater) 14/09/2024:
            init {
                ItemView.setOnCreateContextMenuListener{ menu, v, menuInfo ->
                    run {
                        val menuInflater: MenuInflater = MenuInflater(v.context)
                        menuInflater.inflate(R.menu.menu_item_contato,menu)
                    }

                }
            }
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContatoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contato_layout,parent,false)
        return ContatoViewHolder(view)
    }

    override fun onBindViewHolder(holder: ContatoViewHolder, position: Int) {
        holder.txtNome.text = listaContatos[position].nome //coloquei .nome 14/09/2024
        holder.txtTelefone.text = listaContatos[position].telefone

        holder.itemView.setOnLongClickListener{ v->
            posicaoClicada = holder.adapterPosition
            false
        }
    }

    override fun getItemCount(): Int {
        return listaContatos.count()
    }
}