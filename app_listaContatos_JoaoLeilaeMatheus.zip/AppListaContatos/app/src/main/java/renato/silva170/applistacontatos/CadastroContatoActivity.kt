package renato.silva170.applistacontatos

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import renato.silva170.applistacontatos.models.Contato
import renato.silva170.applistacontatos.retrofit.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CadastroContatoActivity : AppCompatActivity() {
    var contato:Contato?=null
    lateinit var txtNome:EditText
    lateinit var txtEmail:EditText
    lateinit var txtTelefone:EditText
    lateinit var txtEndereco:EditText
    lateinit var btnSalvar:Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro_contato)
        txtNome = findViewById(R.id.txtNome)
        txtEmail = findViewById(R.id.txtEmail)
        txtEndereco = findViewById(R.id.txtEndereco)
        txtTelefone = findViewById(R.id.txtTelefone)
        btnSalvar = findViewById(R.id.btnSalvar)
        btnSalvar.setOnClickListener { salvaContato() }

        if(this.intent.hasExtra("contato"))
        {
            contato = this.intent.getSerializableExtra("contato") as Contato
            preencheContato(contato!!)
        }
    }

    private fun salvaContato() {
        if (contato == null){
            cadastraContato()
        }
    }

    private fun cadastraContato() {
        var novoContato:Contato = getNovoContato()
        RetrofitClient.servicoContatos.insereContatos(novoContato).enqueue(object : Callback<Contato>{
                override fun onResponse(call: Call<Contato>, response: Response<Contato>) {
                    if (response.isSuccessful) {
                        Toast.makeText(
                            this@CadastroContatoActivity,
                            "Cadastro Concluído",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(
                            this@CadastroContatoActivity,
                            "Falha no Cadastro",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun onFailure(call: Call<Contato>, t: Throwable) {
                    Toast.makeText(
                        this@CadastroContatoActivity,
                        "Falha no Cadastro",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
    }

    private fun getNovoContato(): Contato {
        var contato:Contato = Contato("", txtNome.text.toString(),txtEmail.text.toString(), txtTelefone.text.toString(),txtEndereco.text.toString(),"#")
        return  contato
    }

    private fun preencheContato(contato: Contato) {
        txtNome.setText(contato.nome)
        txtTelefone.setText(contato.telefone)
        txtEndereco.setText(contato.endereco)
        txtEmail.setText(contato.email)
    }
}