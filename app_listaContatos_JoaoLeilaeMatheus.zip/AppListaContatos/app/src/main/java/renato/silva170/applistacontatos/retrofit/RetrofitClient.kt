package renato.silva170.applistacontatos.retrofit

import renato.silva170.applistacontatos.servicos.ServicosContatos
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    private const val BASE_URL = "https://api-mong-db-yp8x.onrender.com/"
    private var retrofit: Retrofit? = null

    val client: Retrofit
        get() {
            if (retrofit == null){
                retrofit  = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return  retrofit!!
        }
    val servicoContatos = client.create(ServicosContatos::class.java)
}
