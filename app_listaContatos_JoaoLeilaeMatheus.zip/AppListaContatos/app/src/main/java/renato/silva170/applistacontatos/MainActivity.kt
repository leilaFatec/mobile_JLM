package renato.silva170.applistacontatos

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import renato.silva170.applistacontatos.adapters.ContatosAdapter
import renato.silva170.applistacontatos.models.Contato
import renato.silva170.applistacontatos.retrofit.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    var listaContatos:ArrayList<Contato> = ArrayList() //alterei String para contato


    lateinit var listContatos:RecyclerView
    lateinit var btnCadastrar:Button

    //criando lista de contatos: 14/09/2024

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listContatos = findViewById(R.id.listContatos)
        btnCadastrar = findViewById(R.id.btnCadastrar)
        btnCadastrar.setOnClickListener{(cadastrarContato())}

        carregaContatos();


    }

    private fun cadastrarContato() {
        var intent:Intent = Intent(this,CadastroContatoActivity::class.java)
        startActivity(intent)

    }

    private fun carregaContatos() {
        RetrofitClient.servicoContatos.getContatos().enqueue(object : Callback<List<Contato>> {
            override fun onResponse(call: Call<List<Contato>>, response: Response<List<Contato>>) {
                if (response.isSuccessful) {
                    listaContatos = response.body() as ArrayList<Contato>
                    listContatos.adapter = ContatosAdapter(listaContatos)
                    listContatos.layoutManager = LinearLayoutManager(this@MainActivity)
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "falha ao carregar contatos",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<List<Contato>>, t: Throwable) {
                Toast.makeText(this@MainActivity, "falha ao carregar contatos", Toast.LENGTH_LONG)
                    .show()
            }
        })
    }


    //criei 14/09/2024
    override fun onContextItemSelected(item: MenuItem): Boolean {
        var posicao = (listContatos.adapter as ContatosAdapter).posicaoClicada
        var contato = listaContatos[posicao]
        //var menuInfo = item.menuInfo as AdapterView.AdapterContextMenuInfo

        if(item.itemId==R.id.menu_mapa){
            val uri = Uri.parse("geo:0,0?q="+contato.endereco+"&z=18")
            val intent = Intent(Intent.ACTION_VIEW, uri )
            startActivity(intent)
        }
        else if(item.itemId==R.id.menu_email){
            val uri = Uri.parse("mailto:"+contato.email)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
        else if (item.itemId==R.id.menu_telefone)
        {
            val uri = Uri.parse("tel:"+contato.telefone)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
        else if(item.itemId==R.id.menu_editar){
            val intent = Intent(this,CadastroContatoActivity::class.java)
            intent.putExtra("contato",contato)

            startActivity(intent)
        }





        return super.onContextItemSelected(item)
    }
}